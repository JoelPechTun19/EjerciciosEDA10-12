export class Cliente {
    //* constrcutor como en el C# en el cual se pasan las variabales de nuevo;
    constructor(numeroTurno, nombre, tipoMovimiento, horaDeLlegada) {
        this.numeroTurno = numeroTurno;
        this.nombre = nombre;
        this.tipoMovimiento = tipoMovimiento;
        this.horaDeLlegada = horaDeLlegada;
    }
}
