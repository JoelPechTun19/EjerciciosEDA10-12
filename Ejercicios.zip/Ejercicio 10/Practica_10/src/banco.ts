import { Cliente } from "./cliente";

export class Banco {
    cola: Cliente[] = [];
    //Definimos en maximo que puede llevar la cola
    capacidadMaxima: number = 10;

//* Metodo para calcular si la cola se encuentra llena
    colaLlena() {
        return this.cola.length >= this.capacidadMaxima;
    }

//* Metodo para calcular si la cola se encuentra vacia
    colaVacia() {
        return this.cola.length === 0;
    }

//* Metodo para agregar un cliente a la cola
    agregarCliente(cliente: Cliente) {
        //Si la cola se encuenta llena este manda una alerta!!
        if(this.colaLlena()) {
            alert('La cola esta llena. No se pueden agregar más clientes');
        }
        this.cola.push(cliente);
    }

//* Metodo para atender a un cliente (eliminar un cliente de la cola)
    atenderCliente() {
        //Si no hay nigun cliente
        if(this.colaVacia()) {
            alert('No hay clientes');
            return;
        }
        //Se crea una nueva variable para ue almacene los clientes que se vayan eliminando
        const clienteAtendido = this.cola.shift();
        //Verifica si el cliente que se quuiere atender si existe dentro de la cola
        if(clienteAtendido) {
            //Para obtener la hora actual
            const horaActual = new Date();
            //La hora actual se le resta la hora de llegada del cliente 
            const timepoEspera = (horaActual.getTime() - clienteAtendido.horaDeLlegada.getTime()) / 1000;
            alert(`Cliente: ${clienteAtendido.nombre} atendido - Tiempode espera: ${timepoEspera} segundos`)
        }
    }
}