export class Cliente {
//? declarar  la variables con su tipo para poder usarlas
    numeroTurno: number;
    nombre: string;
    tipoMovimiento: string;
    horaDeLlegada: Date;
//* constrcutor como en el C# en el cual se pasan las variabales de nuevo;
    constructor(numeroTurno: number, nombre: string, tipoMovimiento: string, horaDeLlegada: Date) {
        this.numeroTurno = numeroTurno;
        this.nombre = nombre;
        this.tipoMovimiento = tipoMovimiento;
        this.horaDeLlegada = horaDeLlegada;
    }
}
