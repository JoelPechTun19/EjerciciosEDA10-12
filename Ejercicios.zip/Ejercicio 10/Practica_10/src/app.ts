import { Banco } from "./banco";
import { Cliente } from "./cliente";

const banco = new Banco();
//? Declaraciones de variables conectanndolos a un HTMl
const numeroTurnoInput = document.getElementById('numeroTurno') as HTMLInputElement;
const nombreClienteInput = document.getElementById('nombre') as HTMLInputElement;
const tipoMovimientoSelect = document.getElementById('tipoMovimiento') as HTMLSelectElement;
const agregarClienteBtn = document.getElementById('agregarCliente') as HTMLButtonElement;
const atenderClienteBtn = document.getElementById('atenderCliente') as HTMLButtonElement;
const colaTable = document.getElementById('colaTable') as HTMLTableElement;

//* Eleccion de una opcion a realizar
tipoMovimientoSelect.addEventListener('change', () => {
    const selectOption = tipoMovimientoSelect.value;
    console.log('Opción seleccionada:', selectOption);
});

//* Boton para agregar a un cliente
agregarClienteBtn.addEventListener('click', () => {
    const nombre = nombreClienteInput.value;
    const tipoMovimiento = tipoMovimientoSelect.value
    const numeroTurno = parseInt(numeroTurnoInput.value);

    //Verificar el nombre, tipo de movimiento y si el numero en turno es agregado sea un numero
    if (!nombre || !tipoMovimiento || isNaN(numeroTurno)) {
        alert('Por favor, ingrese los datos correctamente, incluyendo un número de turno válido.');
        return;
    }
    //Verificar si la cola se encuentra llena
    if(banco.colaLlena()) {
        alert('La cola esta llena. No se pueden agregar más clientes');
        return;
    }
    //Obtener la hora actual (hora de llegada)
    const  horaDeLlegada = new Date();

    const cliente = new Cliente(numeroTurno, nombre, tipoMovimiento, horaDeLlegada);
    banco.agregarCliente(cliente);
    actualizarTablaCola();

    const mensaje = `Cliente ${cliente.numeroTurno} - Nombre: ${cliente.nombre}, Tipo de Movimiento: ${cliente.tipoMovimiento}, Hora de Llegada: ${cliente.horaDeLlegada.toLocaleTimeString()}`;
    alert(mensaje);
});

atenderClienteBtn.addEventListener('click', () => {
    if(banco.colaVacia()) {
        alert('No hay clientes para atender');
        return;
    }
    banco.atenderCliente();
    actualizarTablaCola();
});

function actualizarTablaCola() {
    const tableBody = colaTable.querySelector('tbody');
    if(tableBody) {
        while (tableBody.firstChild) {
            tableBody.removeChild(tableBody.firstChild);
        }

        banco.cola.forEach((cliente) => {
            const fila= tableBody.insertRow();
            fila.insertCell(0).textContent = cliente.numeroTurno.toString();
            fila.insertCell(1).textContent = cliente.nombre;
            fila.insertCell(2).textContent = cliente.tipoMovimiento;
            fila.insertCell(3).textContent = cliente.horaDeLlegada.toLocaleTimeString();
        });
    }
}
