import { Auto } from './auto.js';
import { ColaCircularDoblementeLigada } from './colaCircularDoblementeLigada.js';

export class Estacionamiento {
  constructor() {
    this.autos = new ColaCircularDoblementeLigada();
  }

  entradaAuto(placas, propietario) {
    const horaEntrada = new Date();

    if (/\d/.test(propietario)) {
      alert("El nombre del propietario no puede contener números.");
      return null; // Abortar la entrada del auto
    }
    const auto = new Auto(placas, propietario, horaEntrada);
    this.autos.encolar(auto);
    return auto;
  }

  salidaAuto() {
    const auto = this.autos.desencolar();
    return auto;
  }
}
