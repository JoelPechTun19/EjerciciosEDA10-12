class Nodo {
  constructor(dato) {
    this.dato = dato;
    this.siguiente = null;
    this.anterior = null;
  }
}

export class ColaCircularDoblementeLigada {
  constructor() {
    this.primero = null;
    this.ultimo = null;
  }

  encolar(dato) {
    const nuevoNodo = new Nodo(dato);

    if (!this.primero) {
      this.primero = nuevoNodo;
      this.ultimo = nuevoNodo;
    } else {
      nuevoNodo.anterior = this.ultimo;
      nuevoNodo.siguiente = this.primero;
      this.ultimo.siguiente = nuevoNodo;
      this.primero.anterior = nuevoNodo;
      this.ultimo = nuevoNodo;
    }
  }

  desencolar() {
    if (!this.primero) {
      return null;
    }

    const dato = this.primero.dato;

    if (this.primero === this.ultimo) {
      this.primero = null;
      this.ultimo = null;
    } else {
      this.primero = this.primero.siguiente;
      this.primero.anterior = this.ultimo;
      this.ultimo.siguiente = this.primero;
    }

    return dato;
  }
}
