import { Estacionamiento } from './estacionamiento.js';

const estacionamiento = new Estacionamiento();

// Asignar funciones al ámbito global
window.entradaAuto = function () {
  const placas = prompt("Ingrese las placas del auto:");
  const propietario = prompt("Ingrese el nombre del propietario:");
  const auto = estacionamiento.entradaAuto(placas, propietario);
  if (auto) {
     alert("¡Entrada de auto exitosa!");
    const output = document.getElementById("output");
    output.innerHTML = `<p>Auto ingresado:<br>Placas: ${auto.placas}<br>Propietario: ${auto.propietario}<br>Hora de entrada: ${auto.horaEntrada.toLocaleString()}</p>`;
  } else {
    alert("No se pudo ingresar el auto.");
  }
};

window.salidaAuto = function () {
  const auto = estacionamiento.salidaAuto();
  if (auto) {
    const costo = auto.calcularCosto();
    const output = document.getElementById("output");
    output.innerHTML = `<p>Auto saliendo:<br>Placas: ${auto.placas}<br>Propietario: ${auto.propietario}<br>Hora de entrada: ${auto.horaEntrada.toLocaleString()}<br>Hora de salida: ${new Date().toLocaleString()}<br>Costo: $${costo}</p>`;
  } else {
    alert("El estacionamiento está vacío.");
  }
};
