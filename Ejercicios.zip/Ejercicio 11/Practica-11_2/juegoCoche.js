export class JuegoCoche {
    constructor() {
        this.colores = ['Rojo', 'Azul', 'Amarillo', 'Verde', 'Morado', 'Rosado', 'Naranja'];
        this.cocheCola = [];
        this.colorActual = this.colorRandom();
        this.maxCoches = 5;
        this.cochesAlineados = 0;
        this.intervaloTiempo = null;
        this.velocidad = 3000;
        this.cochesPintados = 0;
        this.tiempoTranscurrido = 0;

        this.carosTexto = document.querySelector('.car-color-text');
        this.containerCoche = document.querySelector('.coche-container');
        this.paletaColores = document.querySelector('.paleta-colores');
        this.colorBtns = document.querySelectorAll('.color-button');
        this.iniciarBtn = document.getElementById('iniciarBtn');

        this.cochesAtendidos = document.querySelector('.carrosAtendidos-container');
        this.resultados = document.querySelector('.resultado-container');
        this.resultadosText = document.getElementById('resulatado');

        this.record = {
            cochesPintados: 0,
            tiempoInicio: null,
            tiempoFinal: null,
            tiempoTotal: 0
        };

        this.endGameCallback = null;
        this.juegoTerminado = false;
        this.iniciarJuego();
    }

    iniciarJuego() {
        clearInterval(this.intervaloTiempo);
        this.record.tiempoInicio = new Date().getTime();
        this.obtenerpaletaColores();
        this.agregarCoche();

        this.intervaloTiempo = setInterval(() => {
            this.incrementarVelocidad();
            this.agregarCoche();
            this.tiempoTranscurrido += this.velocidad / 1000;

            if (this.tiempoTranscurrido >= 20) {
                // Realizar el enfilamiento de coches aquí.
                this.agregarCoche();
                this.tiempoTranscurrido = 0; // Reiniciar el tiempo transcurrido.
            }
        }, this.velocidad);
    }

    reiniciarJuego() {
        clearInterval(this.intervaloTiempo);
        this.cocheCola = [];
        this.cochesAlineados = 0;
        this.cochesPintados = 0;
        this.cochesAtendidos.innerHTML = '';
        this.containerCoche.innerHTML = '';
        this.resultados.textContent = '';
        this.paletaColores.innerHTML = '';
        this.record.cochesPintados = 0;
        this.record.tiempoInicio = null;
        this.record.tiempoFinal = null;
        this.record.tiempoTotal = 0;

        this.obtenerpaletaColores();
    }

    botonReiniciar() {
        this.juegoTerminado = false;

        this.colorBtns.forEach((boton) => {
            boton.classList.remove('disabled')
        });
    }

    obtenerpaletaColores() {
        this.paletaColores.innerHTML = '';

        this.colores.forEach((color) => {
            const colorBtn = document.createElement('div');
            colorBtn.className = `color-button ${color}`;
            if(!this.juegoTerminado) {
                colorBtn.addEventListener('click', () => this.pintarCoche(color));
            } else {
                colorBtn.classList.add('disabled');
            }
            this.paletaColores.appendChild(colorBtn);
        });
    }

    agregarCoche() {
        const contenedorCoches = document.createElement('div');
        contenedorCoches.className = 'unitCar-Container';

        const coche = document.createElement('img');
        coche.className = 'coche';
        coche.classList.add('unpainted');
        const cocheColor = this.colorRandom();
        coche.src = "img/carro-blanco.png";
        coche.dataset.color = cocheColor;

        const colorCocheText = document.createElement('p');
        colorCocheText.className = 'coche-color-text';
        colorCocheText.textContent = cocheColor;

        contenedorCoches.appendChild(coche);
        contenedorCoches.appendChild(colorCocheText);

        this.cocheCola.push(contenedorCoches);
        this.containerCoche.appendChild(contenedorCoches);
        this.cochesAlineados++;

        // Verificar si hay 5 coches sin pintar y detener el juego si es así.
        if (this.cochesAlineados - this.record.cochesPintados >= this.maxCoches) {
            this.finJuego();
        }
    }

    pintarCoche(color) {
        if (!this.juegoTerminado) {
            const ningunCochePintado = this.containerCoche.querySelector('.unpainted');
            if (ningunCochePintado) {
                const colorCoche = ningunCochePintado.dataset.color;
    
                if (colorCoche === color) {
                    ningunCochePintado.classList.remove('unpainted');
                    ningunCochePintado.src = `img/carro-${color}.png`;
    
                    const cochesAtendidos = document.querySelector('.carrosAtendidos-container');
                    cochesAtendidos.appendChild(ningunCochePintado);
    
                    const cocheText = document.querySelector('.coche-color-text');
                    cocheText.remove();
    
                    this.cocheCola.shift();
                    this.record.cochesPintados++;
                }
            }
        }
    }

    colorRandom() {
        return this.colores[Math.floor(Math.random() * this.colores.length)];
    }

    incrementarVelocidad() {
        if(this.cochesAtendidos % 3 === 0) {
            this.velocidad -= 1000;
        }
    }

    mostrarRecord() {
        if(this.record.tiempoInicio && this.record.tiempoFinal) {
            this.record.tiempoTotal = (this.record.tiempoFinal - this.record.tiempoInicio) / 1000;
            this.resultados.textContent = `Record: Coches Pintados ${this.record.cochesPintados}, Tiempo total fue: ${(this.record.tiempoTotal).toFixed(2)} segundos`;
        }
    }

    finJuego() {
        if(!this.juegoTerminado) {
            this.juegoTerminado = true;
            clearInterval(this.intervaloTiempo);
            this.record.tiempoFinal = new Date().getTime();
            this.mostrarRecord();

            this.colorBtns.forEach((boton) => {
                boton.classList.add('disabled')
            });
        }
    }
}