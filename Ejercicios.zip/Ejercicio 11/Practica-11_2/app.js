import { JuegoCoche } from "./juegoCoche.js";

let juego = null;
const iniciarBtn = document.getElementById('iniciarBtn');
const reiniciarBtn = document.getElementById('reiniciarBtn');

iniciarBtn.addEventListener('click', () => {
    iniciarBtn.style.display = 'none';
    // reiniciarBtn.style.display = 'inline';

    if(juego) {
        juego.iniciarJuego();
    } else {
        juego = new JuegoCoche();
    }
});
// reiniciarBtn.addEventListener('click', () => {
//     juego.reiniciarJuego();
//     iniciarBtn.style.display = 'inline';
//     reiniciarBtn.style.display = 'none';
//     juego.botonReiniciar();

//     setTimeout(() => {
//         juego.velocidad = 2000;
//         juego.iniciarJuego();
//     }, 1000);
// });